/** Automatically generated file. DO NOT MODIFY */
package com.arjun.app.memorysisya;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}