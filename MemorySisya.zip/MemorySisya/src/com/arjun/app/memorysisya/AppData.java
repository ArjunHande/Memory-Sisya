package com.arjun.app.memorysisya;

import android.os.Debug.MemoryInfo;

public class AppData
{
	public String packageName;
	public String appName;
	public MemoryInfo size;
}
